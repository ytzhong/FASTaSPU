## ------------------------------------------------------------------------
suppressMessages(library(MASS))
y <- rnorm(1000,0,1)
x <- mvrnorm(1000,rep(0,100),diag(rep(1,100)))
#using the speed-up permutation procedure
suppressMessages(library(aSPUperm))
system.time(result_FASTaSPU <- aSPU_perm(Y=y, X=x, cov = NULL, family = "gaussian", pow = c(1:8, Inf), n.perm = 10000, speedup=T)$pvs['aSPU'] )
print(result_FASTaSPU)

suppressMessages(library(aSPU))
system.time(result_aSPU <- aSPU(Y=y, X=x, cov = NULL, model = "gaussian", pow = c(1:8, Inf), n.perm = 10000, resample='perm')$pvs['aSPU'] )
print(result_aSPU)


