perm.slowwalk <- function(U,r, n.perm, XUs,seed){
U0 <- rep(NA, (length(n.perm)))
     set.seed(seed)
	 for (b in 1:(n.perm)) {
          	if ( b%%100==0 | b==1 ) {
        	  r0 <- sample(r, length(r), replace=F)  
        	  U0[b] <-  as.vector(t(XUs) %*% r0 )
        	} else {
        	  index <- sample(1:length(r),2, replace=F)
            U0[b] <- U0[b-1] - (XUs[index[1]] - XUs[index[2]] ) * (r0[index[1]] - r0[index[2]] )
	          r0 <- replace(r0, index, r0[c(index[2],index[1])])   
        	}
	   }
U0 <- round(U0, digits=6)
U <- round(U, digits=6)
pvalue <- sum(abs(as.vector(U)) < abs(U0))/n.perm
return(pvalue)
}

perm <- function(U,r,n.perm, XUs,seed){
	U0 <- rep(NA, length(n.perm))
	 set.seed(seed)
	 for (b in 1:(n.perm)) {
         r0 <- sample(r, length(r), replace=F)  
         U0[b] <- t(XUs) %*% r0              
}
U0 <- round(U0, digits=6)
U <- round(U, digits=6)
pvalue <- sum(abs(as.vector(U)) < abs(U0))/n.perm
return(pvalue)
}

#' Function to calculate p-values of each single variable in a general linear model using permutation. It could be adapted to test single variants in GWAS association analysis.
#' @param Y A n X 1 outcome vector. The function supports quantitative and binary outcomes
#' @param X A n X k matrix
#' @param family "gaussian" for quantitative outcome, "binomial" for binary outcomes
#' @param n.perm Number of permutations
#' @param speedup "T" if using our speed-up permutation version, "F" if using the traditional permutation method
#' @keywords GLM
#' @export
#' @return A list contains point estimates, p-values, and number of permuations
#' @examples {
#' library(MASS)
#' data(cats)
#' glm_perm(Y=cats[,2], X=cats[,c(1,3)], family='gaussian',n.perm=1e3, speedup=TRUE)
#' }
glm_perm <- function(Y, X,  family = c("gaussian", "binomial"), n.perm = 1e5, speedup=TRUE) {
	model = match.arg(family)
    n <- length(Y)
    if (is.null(X))  stop('please specify the independent variables.')
    if (any(is.character(X))) stop('Character values are not acceptable in X')
    if (any(is.character(Y))) stop('Character values are not acceptable in Y')
    X <- as.matrix(sapply(X, as.numeric))
    k <- ncol(X)
    if (is.null(colnames(X))) colnames(X) <- paste('x',1:k, sep='')   
    #calculate the point estimate
    point <- stats::glm(Y~X, family=model)$coefficients
    
    #permuted p-value for individual tests
    	U <-  vector()
    	p <- vector()
    	X <- cbind(1, X)
    	
    	for (j in 1:ncol(X)) {
    	  cov <- X[,-j]
        tdat1 <- data.frame(trait = Y, cov)
        fit1 <- stats::glm(trait ~ . -1  , family = model, data = tdat1)
        pis <- stats::fitted.values(fit1)
        r <- Y - pis
        tdat2 <- data.frame(X1=X[,j], cov)
        fit2 <- stats::glm(X1 ~ . -1, data=tdat2)
        XUs <- stats::residuals(fit2)   
        U <- t(XUs) %*% r
        seed <- sample(1:10^5, 1)
        
        p[j] <- ifelse(speedup, perm.slowwalk(U, r, n.perm, XUs, seed), perm(U, r, n.perm, XUs, seed))
    }

    names(p) <- names(point) <- c('Intercept', colnames(X)[2:(k+1)])
     
    return(list(point_estimates = point, p_value=p, n_perm=n.perm))
    }
