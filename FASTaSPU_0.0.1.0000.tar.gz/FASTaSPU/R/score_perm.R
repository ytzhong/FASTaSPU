#' Function to calculate p-values for the score test using permutation
#' @param Y a n X 1 outcome vector. The function supports quantitative and binary outcomes. For example, it can be a disease indicator; = 0 for controls, = 1 for cases. n is the number of subjects
#' @param X a n X k matrix. For example, the genotype matrix with each column for an SNP (or a predictor) 
#' @param cov a n X q covariate matrix
#' @param family "gaussian" for a quantitative trait, "binomial" for a binary trait
#' @param n.perm number of permutations
#' @param speedup "T" if using our speed-up permutation version, "F" if using the traditional permutation method
#' @keywords score test
#' @export
#' @return A list object that contains: p values from permutation and asymptotic distribution
#' @examples {
#' library(aSPU)
#' data(exdat)
#' score_perm(Y=exdat$Y, X=exdat$X, family='gaussian',n.perm=1e5, speedup=TRUE)
#' }

score_perm<- function (Y, X, cov = NULL, family = c("gaussian", "binomial"),  n.perm = 1000, speedup=TRUE) {
    model = match.arg(family)
    n <- length(Y)
    if (any(is.character(X))) stop('Character values are not acceptable in X')
    if (any(is.character(Y))) stop('Character values are not acceptable in Y')
    if (any(is.character(cov))) stop('Character values are not acceptable in cov')
    if (is.null(X) && length(X) > 0) 
        X = as.matrix(X, ncol = 1)
    k <- ncol(X)
    if (is.null(cov)) {
        XUs <- Xg <- X
        r <- Y - mean(Y)
        U <- as.vector(t(Xg) %*% r)
        cov <- matrix(1)
        A22 <- t(XUs) %*% XUs
        A11 <- n
        A12 <- t(apply(XUs,2,sum))
        A21 <- t(A12)
        J <- XUs %*% solve(A22 - A21 %*% A12 /n) %*% t(XUs)
    } else {
        cov <- as.matrix(sapply(cov, as.numeric))
        tdat1 <- data.frame(trait = Y, cov)
        if (is.null(colnames(cov))) {
            colnames(tdat1) = c("trait", paste("cov", 1:dim(cov)[2], 
                sep = ""))
        } else {
            colnames(tdat1) = c("trait", colnames(cov))
        }
        fit1 <- stats::glm(trait ~ ., family = model, data = tdat1)
        pis <- stats::fitted.values(fit1)
        XUs <- matrix(0, nrow = n, ncol = k)
        Xmus = X
        for (i in 1:k) {
            tdat2 <- data.frame(X1 = X[, i], cov)
            fit2 <- stats::glm(X1 ~ ., data = tdat2)
            Xmus[, i] <- stats::fitted.values(fit2)
            XUs[, i] <- (X[, i] - Xmus[, i])
        }
        r <- Y - pis
        U <- t(XUs) %*% r
        
        #calculate the variance matrix
        cov <- cbind(1, cov)
        A22 <- t(XUs) %*% XUs
        A11 <- t(cov) %*% cov
        A12 <- t(cov) %*% XUs
        A21 <- t(A12)
        J <- XUs %*% solve(A22 - A21 %*% solve(A11) %*% A12) %*% t(XUs)
    }
    Ts = as.vector(t(r) %*% J %*% r)
  
    s <- sample(1:10^5, 1)
    if (speedup) {result <- permScore.slowwalk(s,n.perm, U, r, J, Ts)} else result <- permScore(s,n.perm, U, r, J, Ts)
    asymptotic <- stats::pchisq(Ts, df=k, lower.tail=F)
    result <- c(result, asymptotic)
    names(result) <-c('permuted p','asymptotic p')
    return(result)
}

permScore.slowwalk <- function( s, n.perm, U, r, J, Ts) {  
	      r<-as.matrix(r,ncol=1)
        T0s = numeric(n.perm)
        set.seed(s)
        for (b in 1:(n.perm )) {
            if (b%%100==0 | b==1) {
              r0 <- sample(r, length(r), replace=F)  
              T0s[b] <- as.vector(t(r0) %*% J %*% r0 )
              #T0s[1] <- Ts; r0=r
              } else {
            index <- sample(1:length(r),2)
            T0s[b] <- T0s[b-1] - 2*  (r0[index[1]]- r0[index[2]]) * sum(t(r0[-index]) * (J[index[1],-index] - J[index[2],-index]) ) -    (r0[index[1]]^2 - r0[index[2]]^2) * (J[index[1],index[1]] - J[index[2],index[2]]) 
            r0 <- replace(r0, index, r0[c(index[2],index[1])]) 
           }        
        	  }
        P0s = sum(abs(Ts) <= abs(T0s))/n.perm
        return(P0s)
    }
 

permScore <- function( s, n.perm, U, r, J, Ts) { 
	      r<-as.matrix(r,ncol=1)
        T0s = numeric(n.perm)
        set.seed(s)
        for (b in 1:(n.perm)) {
        	r0 <- sample(r, length(r), replace=F)  
            T0s[b] <- as.vector(t(r0) %*% J %*% r0 )                           
        }
       
        P0s = sum(abs(Ts) <= abs(T0s))/n.perm
        return(P0s)
    }
 
  