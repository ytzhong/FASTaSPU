#' Function to calculate p-values for the adaptive sum of powered score (aSPU) test using permutation
#' @param Y a n X 1 outcome vector. The function supports quantitative and binary outcomes. For example, it can be a disease indicator; = 0 for controls, = 1 for cases. n is the number of subjects
#' @param X a n X k matrix. For example, the genotype matrix with each column for an SNP (or a predictor) 
#' @param cov a n X q covariate matrix
#' @param family "gaussian" for a quantitative trait, "binomial" for a binary trait
#' @param n.perm number of permutations
#' @param speedup "T" if using our speed-up permutation version, "F" if using the traditional permutation method
#' @param pow power used in SPU test. A vector of the powers. Usually (1:8, Inf) suffices thus used as default
#' @keywords aSPU
#' @export
#' @return A list object that contains: Ts:test statistics for the SPU tests in the order of the specified pow ; pvs: p-values for the SPU and the aSPU tests.
#' @examples {
#' library(aSPU)
#' data(exdat)
#' aSPU_perm(Y=exdat$Y, X=exdat$X, family='gaussian',n.perm=1e3, speedup=TRUE)
#' }
aSPU_perm<- function (Y, X, cov = NULL, family = c("gaussian", "binomial"), pow = c(1:8, Inf), n.perm = 1000, speedup=TRUE) {
    model = match.arg(family)
    n <- length(Y)
    if (any(is.character(X))) stop('Character values are not acceptable in X')
    if (any(is.character(Y))) stop('Character values are not acceptable in Y')
    if (any(is.character(cov))) stop('Character values are not acceptable in cov')
    if (is.null(X) && length(X) > 0) 
        X = as.matrix(X, ncol = 1)
    k <- ncol(X)
    if (is.null(cov)) {
        XUs <- Xg <- X
        r <- Y - mean(Y)
        U <- as.vector(t(Xg) %*% r)
    } else {
        cov <- as.matrix(sapply(cov, as.numeric))
        tdat1 <- data.frame(trait = Y, cov)
        if (is.null(colnames(cov))) {
            colnames(tdat1) = c("trait", paste("cov", 1:dim(cov)[2], 
                sep = ""))
        } else {
            colnames(tdat1) = c("trait", colnames(cov))
        }
        fit1 <- stats::glm(trait ~ ., family = model, data = tdat1)
        pis <- stats::fitted.values(fit1)
        XUs <- matrix(0, nrow = n, ncol = k)
        Xmus = X
        for (i in 1:k) {
            tdat2 <- data.frame(X1 = X[, i], cov)
            fit2 <- stats::glm(X1 ~ ., data = tdat2)
            Xmus[, i] <- stats::fitted.values(fit2)
            XUs[, i] <- (X[, i] - Xmus[, i])
        }
        r <- Y - pis
        U <- t(XUs) %*% r
    }
  
    s <- sample(1:10^5, 1)
    if (speedup) {result <- permA.slowwalk(pow,s,n.perm, U, r, XUs)} else result <- permA(pow,s,n.perm, U, r, XUs)
    return(result)
}

permA.slowwalk <- function(pow, s, n.perm, U, r, XUs) {  
        Ts = rep(NA, length(pow))
        for (j in 1:length(pow)) {
        if (pow[j] < Inf)  Ts[j] = sum(U^pow[j]) else Ts[j] = max(abs(U))
        }
  
        pPerm0 = rep(NA, length(pow))
        T0s = matrix(NA, nrow=n.perm, ncol=length(pow))
        P0s <- matrix(NA,n.perm,length(pow))
        #for (j in 1:length(pow)) {
        set.seed(s)
        for (b in 1:n.perm) {
        
        	  if ( b%%100==0 | b==1) {
        	  r0 <- sample(r, length(r), replace=F)  
        	  U0 <-  t(XUs) %*% r0 
        	} else  {
        	  index <- sample(1:length(r),2)
            U0 <- U0 - t(XUs[index,]) %*%  (r0[index]- r0[c(index[2],index[1])])
            r0 <- replace(r0, index, r0[c(index[2],index[1])])  
        	}
            
         for (j in 1:length(pow)) {          	     	
           if (pow[j] < Inf) {
                T0s[b,j] = sum(U0^pow[j])
            }
            if (pow[j] == Inf) {
                T0s[b,j] = max(abs(U0))
            }           
        }
 }
        
        pPerm0[j] = sum(abs(Ts[j]) <= abs(T0s))/n.perm
        
		for (j in 1:length(pow)){
		pPerm0[j] <- round((sum(abs(Ts[j])<=abs(T0s[1:(n.perm-1),j]))+1)/(n.perm), digits = 8) 
		P0s[,j] <- (n.perm-rank(abs(T0s[,j]))+1)/(n.perm)
		}
		minp0 <- apply(P0s,1,min)
		Paspu <- (sum(minp0 <= min(pPerm0)) + 1)/(n.perm + 1)
		pvs <- c(pPerm0, Paspu)
		Ts <- c(Ts, min(pPerm0))
		names(Ts) <- c(paste("SPU", pow, sep = ""), "aSPU")
		names(pvs) = names(Ts)
		list(Ts = Ts, pvs = pvs)
}

permA <- function(pow, s, n.perm, U, r, XUs) {  
  Ts = rep(NA, length(pow))
  for (j in 1:length(pow)) {
    if (pow[j] < Inf)  Ts[j] = sum(U^pow[j]) else Ts[j] = max(abs(U))
  }
  
  pPerm0 = rep(NA, length(pow))
  T0s = numeric(n.perm)
  for (j in 1:length(pow)) {
    set.seed(s)
    for (b in 1:n.perm) {
      r0 <- sample(r, length(r), replace=F)  
      U0 <- t(XUs) %*% r0 
      
      if (pow[j] < Inf) {
        T0s[b] = sum(U0^pow[j])
      }
      if (pow[j] == Inf) {
        T0s[b] = max(abs(U0))
      }
    }
    
    pPerm0[j] = sum(abs(Ts[j]) <= abs(T0s))/n.perm
    P0s = ((n.perm - rank(abs(T0s))) + 1)/(n.perm)
    if (j == 1) 
      minp0 = P0s
    else minp0[which(minp0 > P0s)] = P0s[which(minp0 > P0s)]
  }
  
  Paspu <- (sum(minp0 <= min(pPerm0)) + 1)/(n.perm + 1)
  pvs <- c(pPerm0, Paspu)
  Ts <- c(Ts, min(pPerm0))
  names(Ts) <- c(paste("SPU", pow, sep = ""), "aSPU")
  names(pvs) = names(Ts)
  return(list(Ts = Ts, pvs = pvs))
}

